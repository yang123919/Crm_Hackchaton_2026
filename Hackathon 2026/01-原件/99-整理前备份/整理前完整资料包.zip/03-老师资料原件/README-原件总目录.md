# 老师资料原件

原件按类型分组；重复文件以 SHA-256 校验后合并为一份。

- `01-PPT与课件/`：老师/主办方提供的 PDF 课件及项目参考 PDF；当前未发现 PPT/PPTX 源文件。
- `02-照片/`：评审标准现场照片。
- `03-视频与录音/`：原始会议录音。
- `04-文字资料/`：会议记录原件。
  - `其他MD/`：Vibe Coding 工作流提示词及其他补充 Markdown。

## 原件清单

### PDF 课件与参考资料
- `Hackathon 2026 Pre-Hackathon Briefing.pdf`：挑战题、日程、竞赛规则和提交要求。
- `Connecting AI API Workshop .pdf`：API 配置工作坊材料。
- `CRM System Demo Video Review and Summary.pdf`：CRM 系统演示视频的审阅与摘要材料。

### 照片
- `IMG_20261022_092039.jpg`：评审比例为创新 30%、技术执行/代码质量 25%、用户体验/演示 15%、垂直领域契合 15%、商业价值 15%。

### 视频与录音
- `录音机-20261022-0957.m4a`

### 文字资料
- `hackathonRecord.md.md`：CRM 需求访谈整理稿。
- `其他MD/vibe_coding_prompt.md`：Plan → Wireframes → Build → Review 工作流指南。

摘要和实现计划统一维护在项目文档中，避免重复维护。
