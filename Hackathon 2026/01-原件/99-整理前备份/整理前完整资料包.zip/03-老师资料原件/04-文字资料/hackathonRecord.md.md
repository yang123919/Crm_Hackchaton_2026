# CRM 移动端与 AI 助手讨论录音整理
# CRM Mobile View & AI Assistant Discussion Transcript

---

## 1. 对话全文双语字幕 (Bilingual Transcript)

| # | 时间戳 / 角色 (Timestamp & Speaker) | 中文原音转写 (Chinese Transcript) | 英文对照翻译 (English Translation) |
|---|---|---|---|
| **01** | **说话人 1 (Speaker 1)** | CRM 的一个还没有 Mobile 的，它有 Mobile，只是 Mobile 不适合用。 | Regarding CRM, there's one part that doesn't have a proper mobile view yet. Well, it has a mobile view, but it's not suitable for practical use. |
| **02** | **说话人 2 (Speaker 2)** | 用大... | You mean using large... |
| **03** | **说话人 1 (Speaker 1)** | 因为 CRM 可以讲是比较适合用 Laptop 用啦。然后你用 Laptop，比如说一个 Salesman 用 Laptop 就很麻烦，他又有这样的困难。 | Because CRM, you could say, is more suitable for desktop/laptop use. But if a salesperson has to use a laptop, it's very inconvenient for them. They face these kinds of difficulties. |
| **04** | **说话人 2 (Speaker 2)** | 所以 Key 资料也是比较差啦？ | So keying in data is also quite inconvenient/poor? |
| **05** | **说话人 1 (Speaker 1)** | 它不能马上 Key In。 | It doesn't allow immediate data entry. |
| **06** | **说话人 2 (Speaker 2)** | 不能马上 Key In？ | Cannot key in on the spot? |
| **07** | **说话人 1 (Speaker 1)** | 不能 On the spot key in。 | Cannot key in on the spot. |
| **08** | **说话人 2 (Speaker 2)** | 那那个 Convert 是 Convert 去哪？去 Excel？ | Then where does that conversion go? Convert to Excel? |
| **09** | **说话人 1 (Speaker 1)** | 没有没有 Convert，它也是其中一个 CRM 的 Module 啦。 | No, no conversion. It's actually one of the modules within the CRM system. |
| **10** | **说话人 2 (Speaker 2)** | CRM 的 Module。 | A module of the CRM. |
| **11** | **说话人 1 (Speaker 1)** | 就是好像比如说你一个 Sales Record，你要先进 Contact，Contact 了我们才能进成一个叫... 它的 Term 是叫 Opportunity 啦，就是可以讲当作是一个 Order 这样子。 | For example, for a sales record, you first enter the Contact. After creating the contact, we can convert/create what's termed an "Opportunity", which you can think of as a potential order. |
| **12** | **说话人 2 (Speaker 2)** | 然后你们是怎样 Store 那个人 User 的 Information？ | Then how do you store the user's information? |
| **13** | **说话人 1 (Speaker 1)** | Store User Information？你是讲 Contact 还是进 Database 还是什么？ | Store user information? Do you mean Contacts, or entry into the Database, or something else? |
| **14** | **说话人 2 (Speaker 2)** | 进 Database。 | Entry into the database. |
| **15** | **说话人 1 (Speaker 1)** | CRM 方面是用 MySQL。 | On the CRM side, we use MySQL. |
| **16** | **说话人 2 (Speaker 2)** | MySQL。 | MySQL. |
| **17** | **说话人 1 (Speaker 1)** | 是 MySQL。 | Yes, MySQL. |
| **18** | **说话人 2 (Speaker 2)** | 然后你会给我们那个 User Data 还是什么？ | Then will you give us that user data, or something similar? |
| **19** | **说话人 1 (Speaker 1)** | 啊，没有。我们只给 Layout，全部都是用 Mock 就可以了。 | Ah, no. We will only provide the UI layout; you can use mock data for everything. |
| **20** | **说话人 2 (Speaker 2)** | 用 Mock，OK。 | Use mock data, OK. |
| **21** | **说话人 2 (Speaker 2)** | 还有，就是有什么问题是你管理那些 Customer Information 的时候，还是 Follow up 他们的时候你会遇到的问题？就是好像做错误啊，还是做错东西？ | Also, what challenges or issues do you encounter when managing customer information or following up with them? Like making mistakes or doing something incorrectly? |
| **22** | **说话人 1 (Speaker 1)** | Follow up 的时候，Maybe 可以讲 Follow up 很主持（及时/频繁），但是我没有时间 Key。因为 CRM 是 Laptop，你要回到你的 Desk 你才能 Key，可能会忘记还是怎么样。 | During follow-ups, maybe you follow up very promptly/frequently, but you don't have time to key in the data. Because CRM requires a laptop, you have to go back to your desk to enter data, which leads to forgetting or other issues. |
| **23** | **说话人 2 (Speaker 2)** | 这样如果你...如果可以在手机做的话，你是会不会...会需要吗？还是你觉得在 Laptop 做就好？ | If so, if you... if it could be done on a mobile phone, would you need that? Or do you think doing it on a laptop is sufficient? |
| **24** | **说话人 1 (Speaker 1)** | 可以啊，如果觉得用 Mobile 可以帮到那个 Salesman 更方便，那就更好。 | Sure. If using mobile can make things more convenient for the sales team, that would be even better. |
| **25** | **说话人 2 (Speaker 2)** | 就是你们现在是还没有做到 Mobile？ | So you haven't implemented a mobile version yet? |
| **26** | **说话人 1 (Speaker 1)** | 没有。 | No. |
| **27** | **说话人 2 (Speaker 2)** | 应该 Laptop 系统？ | Currently just the desktop/laptop system? |
| **28** | **说话人 1 (Speaker 1)** | 它的 Default 就是 Laptop 版本的，就用 Laptop。 | Its default is the laptop version, so we use laptops. |
| **29** | **说话人 2 (Speaker 2)** | Laptop 版本，OK。然后你们不能用...你们遇到不能用手机的原因是因为它的 Field 很多？ | Laptop version, OK. And the reason you can't use mobile is because it has too many fields? |
| **30** | **说话人 1 (Speaker 1)** | 屏幕 Field 是很多。因为好像很多东西，比如说你一个车的 Record，你要 Key 很多，Car Color 啊、Chassis Number 啊、加钱啊，加钱那边就很多 Field 要 Key。 | Screen fields are indeed a lot. Because there's so much information—for instance, for a car record, you need to key in car color, chassis number, additional pricing, etc. There are many fields to fill in there. |
| **31** | **说话人 2 (Speaker 2)** | 然后那个 Field 那些你可以大概给我们知道是有什么 Field 吗？ | Then for those fields, can you give us a general idea of what fields they are? |
| **32** | **说话人 1 (Speaker 1)** | 因为那边你们没有看过的它的 Video 咩？ | Haven't you watched its video over there? |
| **33** | **说话人 2 (Speaker 2)** | Video？我们... | Video? We... |
| **34** | **说话人 1 (Speaker 1)** | 我有 Share 一个链接。 | I shared a link. |
| **35** | **说话人 2 (Speaker 2)** | 哦，上个 Topic 罢了，还有有另外一个 Aspect。OK。 | Oh, that was just for the previous topic. There's another aspect. OK. |
| **36** | **说话人 1 (Speaker 1)** | 等下去看一下。 | Take a look at it later. |
| **37** | **说话人 2 (Speaker 2)** | 然后如果你用 AI Assistant，可以...什么事情会帮到 Sales Team 更多一点？用 AI Empower 的话。 | Then if you use an AI Assistant, what kind of things would help the sales team more? If empowered by AI. |
| **38** | **说话人 1 (Speaker 1)** | 你是讲对 Client 还是对 Developer？ | Do you mean for the Client or for the Developer? |
| **39** | **说话人 2 (Speaker 2)** | 对 Developer，就是它可以帮到你什么更多，用 AI？它能帮到你什么更多？在什么方面？ | For the developers—how can AI help you more? What can it help you with, and in what aspects? |
| **40** | **说话人 1 (Speaker 1)** | 你们是讲用 AI Assistant 去帮 Developer 去 Come out 产品还是什么？ | Are you talking about using an AI assistant to help developers build products or something? |
| **41** | **说话人 2 (Speaker 2)** | 帮你们产品还是解决那个问题啦，AI 可以帮到... | Help with your product or solve that problem. AI can help with... |
| **42** | **说话人 1 (Speaker 1)** | 就 Debug 啊那些等等，就是你们的 Program Management。 | Like debugging and those things, basically your program management. |
| **43** | **说话人 1 (Speaker 1)** | OK，如果你...你们要做出这个 Product 的话，你要 Make sure 它能 Related to 你们的这个 CRM 逻辑。 | OK, if you... if you want to make this product, you need to make sure it can relate to your CRM logic. |
| **44** | **说话人 2 (Speaker 2)** | Related... | Related... |
| **45** | **说话人 1 (Speaker 1)** | 一定要 Related，就是因为你要卖的 Product 一定是要给 Client 的。所以是可以，但是你要讲 Link 回去那个 Product。 | It must be related, because the product you want to sell must be for the client. So it's fine, but you need to explain how to link back to that product. |
| **46** | **说话人 2 (Speaker 2)** | 你们还有什么问题吗？ | Do you have any other questions? |
| **47** | **说话人 2 (Speaker 2)** | 谢谢你，谢谢。 | Thank you, thank you. |

---

## 2. 讨论要点总结 (Key Discussion Points Summary)

### 1. 移动端使用痛点 (Mobile View Issues)
* **系统限制**：现有的 CRM 主要针对 Laptop 设计，移动端体验较差且不适合日常使用。
* **时效性与场景限制**：销售人员（Salesman）外出跟进客户时，无法做到 **On-the-spot key-in**（即时录入数据）。必须等回到办公桌使用电脑后才能录入，容易导致遗漏或忘记。
* **表单复杂性**：由于涉及业务字段极多（例如汽车销售中的车身颜色、底盘编号 Chassis Number、各项附加费用加价等），造成移动端界面适配和填写非常繁琐。

### 2. 业务逻辑与技术架构 (Business Logic & Tech Stack)
* **数据流转逻辑**：CRM 内部流程为先新建/录入 **Contact**（联系人），随后转换为 **Opportunity**（销售机会/订单）。
* **数据库**：后台数据库采用 **MySQL**。
* **数据交接**：无需提供真实的真实用户敏感数据，前端/原型开发仅需要 UI Layout 并配合 **Mock Data** 模拟数据即可。

### 3. AI 助手与产品期望 (AI Assistant & Product Expectations)
* **辅助开发与维护**：AI 可用于程序管理、代码排错（Debug）等开发阶段。
* **业务关联性**：开发 AI 功能或新模块时，必须强关联（Related）到 CRM 的核心业务逻辑与客户实际使用的应用场景中。